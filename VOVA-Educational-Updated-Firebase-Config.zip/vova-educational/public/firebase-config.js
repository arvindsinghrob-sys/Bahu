// Firebase Web App configuration for VOVA Educational.
// These web settings are intended for the browser; never put service-account keys here.
export const firebaseConfig = {
  apiKey: "AIzaSyAgvQm53NOWtsim7b5J77vgJcehpWIKLdg",
  authDomain: "vova-733e8.firebaseapp.com",
  databaseURL: "https://vova-733e8-default-rtdb.firebaseio.com",
  projectId: "vova-733e8",
  storageBucket: "vova-733e8.firebasestorage.app",
  messagingSenderId: "989729558349",
  appId: "1:989729558349:web:05c07c05ed3f6bdcb7b104",
  measurementId: "G-QQZXELJ4K1"
};
